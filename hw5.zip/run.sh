#! /bin/bash
echo 'running self built NN testing'
python3 'Neural Networks/NN_test.py'

echo 'running Pytorch N testing'
python3 'Neural Networks/PytorchNN_test.py'