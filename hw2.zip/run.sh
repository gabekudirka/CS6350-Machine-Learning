#! /bin/bash

echo "The following code takes extremely long to run"

python3 'Ensemble Learning/ensemble_testing.py'
python3 'Linear Regression/linear_regression_testing.py'