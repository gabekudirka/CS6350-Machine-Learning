#! /bin/bash

python3 'SVM/SVM_test.py'
