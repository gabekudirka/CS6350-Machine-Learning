#! /bin/bash

python3 'Perceptron/perceptron_test.py'